# tests/testthat.R
library(testthat)
library(RAGFlowChainR)

test_check("RAGFlowChainR")
